package cau1;

public interface Signal {
    double getAmplitude();
    double getFrequency();
    double getPeriod();
    double getWavelength();
}